from django.urls import path
from views import PerfilDetailView

urlpatterns = [
    path('home/<int:pk>/', PerfilDetailView.as_view(),  name='home'),
]